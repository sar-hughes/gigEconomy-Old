package ca.dal.csci3130.quickcash.jobPostings;

import androidx.test.ext.junit.runners.AndroidJUnit4;

import android.app.Activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.assertion.ViewAssertions.matches;


import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.usermanagement.ViewPreferencesActivity;

@RunWith(AndroidJUnit4.class)
public class DetailedJobPostActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<DetailedJobPostActivity> detailedJobPostTestRule = new ActivityScenarioRule<DetailedJobPostActivity>(DetailedJobPostActivity.class);

    @Before
    public void setup() {
        Intents.init();
    }

    @Test
    public void checkIfTitleShown(){
        Espresso.onView(withId(R.id.JobTitle)).check(matches(withText("Title")));
    }

    @After
    public void tearDown() {
        System.gc();
    }
}
