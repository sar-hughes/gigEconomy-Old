package ca.dal.csci3130.quickcash.usermanagement;

import android.app.Activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;

@RunWith(AndroidJUnit4.class)
public class LoginActivityEspressoTest {

    private String existingEmail = "test5@dal.ca";
    private String correctPassword = "Hello123!";
    private String incorrectPassword = "HiHowAreYou?123";
    private String nonExistingEmail = "notRight@gmail.com";

    @Rule
    public ActivityScenarioRule<LoginActivity> loginActivityTestRule = new ActivityScenarioRule<LoginActivity>(LoginActivity.class);


    @Before
    public void setUp() {
        Intents.init();
    }

    @Test
    public void checkValidLogin(){
        Espresso.onView(withId(R.id.email)).perform(typeText(existingEmail));
        Espresso.onView(withId(R.id.password)).perform(typeText(correctPassword));

        Espresso.onView(withId(R.id.Btn_Login)).perform(click());
        intended(hasComponent(EmployeeHomeActivity.class.getName()));
    }

    @Test
    public void checkNonExistingEmail(){
        Espresso.onView(withId(R.id.email)).perform(typeText(nonExistingEmail));
        Espresso.onView(withId(R.id.password)).perform(typeText(correctPassword));

        Espresso.onView(withId(R.id.Btn_Login)).perform(click());
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @Test
    public void checkInvalidPassword(){
        Espresso.onView(withId(R.id.email)).perform(typeText(existingEmail));
        Espresso.onView(withId(R.id.password)).perform(typeText(incorrectPassword));

        Espresso.onView(withId(R.id.Btn_Login)).perform(click());
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @After
    public void tearDown() throws Exception {
        System.gc();
    }


}
