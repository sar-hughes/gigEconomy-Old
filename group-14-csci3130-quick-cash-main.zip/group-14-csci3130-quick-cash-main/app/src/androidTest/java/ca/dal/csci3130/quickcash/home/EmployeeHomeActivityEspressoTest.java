package ca.dal.csci3130.quickcash.home;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.intent.Intents.intending;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.action.ViewActions.typeText;


import android.util.Log;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.jobPostings.EmployeeJobSearchActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.ViewPreferencesActivity;

public class EmployeeHomeActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<EmployeeHomeActivity> EmployeeHomeTestRule = new ActivityScenarioRule<EmployeeHomeActivity>(EmployeeHomeActivity.class);

    @Before
    public void setup() {
        Intents.init();
    }

    @Test
    public void CheckIfEmployeeLoggedOut() {
        Espresso.onView(withId(R.id.EmployeeLogoutButton)).perform(click());
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @Test
    public void CheckIfSearchStarted(){
        Espresso.onView(withId(R.id.searchPostings)).perform(click());
        intended(hasComponent(EmployeeJobSearchActivity.class.getName()));
    }

    @Test
    public void CheckIfPreferencePageStarted(){
        Espresso.onView(withId(R.id.viewPreferences)).perform(click());
        intended(hasComponent(ViewPreferencesActivity.class.getName()));
    }

    @After
    public void tearDown() {
        System.gc();
    }

}
