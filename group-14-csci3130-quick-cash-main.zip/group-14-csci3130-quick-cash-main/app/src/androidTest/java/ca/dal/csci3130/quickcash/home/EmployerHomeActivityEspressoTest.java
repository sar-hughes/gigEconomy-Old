package ca.dal.csci3130.quickcash.home;


import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.intent.Intents.intending;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.action.ViewActions.typeText;


import android.util.Log;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.jobPostings.AddJobActivity;
import ca.dal.csci3130.quickcash.jobPostings.EmployerJobSearchActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;

@RunWith(AndroidJUnit4.class)
public class EmployerHomeActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<EmployerHomeActivity> EmployerHomeTestRule = new ActivityScenarioRule<EmployerHomeActivity>(EmployerHomeActivity.class);

    @Before
    public void setup() {
        Intents.init();
    }
    @Test
    public void CheckIfEmployerLoggedOut() {
        Espresso.onView(withId(R.id.logout)).perform(click());
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @Test
    public void CheckIfEmployerSearchJobsStarted(){
        Espresso.onView(withId(R.id.searchPostings)).perform(click());
        intended(hasComponent(EmployerJobSearchActivity.class.getName()));
    }

    @Test
    public void CheckAddJobButton(){
        Espresso.onView(withId(R.id.jobPost)).perform(click());
        intended(hasComponent(AddJobActivity.class.getName()));
    }



    @After
    public void tearDown() {
        System.gc();
    }
}
