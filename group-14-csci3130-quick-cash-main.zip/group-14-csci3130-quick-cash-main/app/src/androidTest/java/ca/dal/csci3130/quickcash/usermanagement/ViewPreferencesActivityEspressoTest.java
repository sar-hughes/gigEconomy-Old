package ca.dal.csci3130.quickcash.usermanagement;

import android.app.Activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

@RunWith(AndroidJUnit4.class)
public class ViewPreferencesActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<ViewPreferencesActivity> viewPreferencesTestRule = new ActivityScenarioRule<ViewPreferencesActivity>(ViewPreferencesActivity.class);

    @Before
    public void setup() {
        Intents.init();
    }

    @Test
    public void checkDoneButton(){
        Espresso.onView(withId(R.id.done)).perform(click());
        intended(hasComponent(EmployeeHomeActivity.class.getName()));
    }

    @After
    public void tearDown() {
        System.gc();
    }
}
