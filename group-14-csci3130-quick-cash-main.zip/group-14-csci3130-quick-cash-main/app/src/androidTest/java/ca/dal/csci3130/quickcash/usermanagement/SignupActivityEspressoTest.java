package ca.dal.csci3130.quickcash.usermanagement;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.ext.junit.rules.ActivityScenarioRule;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intending;
import static androidx.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.*;
import androidx.test.espresso.action.TypeTextAction;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.intent.Intents.init;



import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

@RunWith(AndroidJUnit4.class)
@LargeTest
public class SignupActivityEspressoTest {
    private String fName = "test";
    private String lName = "ignore";
    private String email = "test@gmail.com";
    private String password = "Hello12345!";
    private String confirm = "Hello12345!";
    private String phone = "9021234567";

    @Rule
    public ActivityScenarioRule<SignupActivity> signupActivityTestRule = new ActivityScenarioRule<>(SignupActivity.class);


    @Before
    public void setUp() throws Exception {
        Intents.init();
        signupActivityTestRule.getScenario();
    }



    @Test
    public void successfulEmployerTest(){
        ActivityScenario scenario = signupActivityTestRule.getScenario();

        Espresso.onView(withId(R.id.firstName)).perform(typeText(fName));
        Espresso.onView(withId(R.id.lastName)).perform(typeText(lName));
        Espresso.onView(withId(R.id.email)).perform(typeText(email));
        Espresso.onView(withId(R.id.password)).perform(typeText(password));
        Espresso.onView(withId(R.id.confirm)).perform(typeText(confirm));
        Espresso.onView(withId(R.id.phone)).perform(typeText(phone));
        Espresso.closeSoftKeyboard();
        Espresso.onView(withId(R.id.employer)).perform(click());
        // verify activity change
        intended(hasComponent(LoginActivity.class.getName()));

    }
    @Test
    public void successfulEmployeeTest(){
        Espresso.onView(withId(R.id.firstName)).perform(typeText(fName));
        Espresso.onView(withId(R.id.lastName)).perform(typeText(lName));
        Espresso.onView(withId(R.id.email)).perform(typeText(email));
        Espresso.onView(withId(R.id.password)).perform(typeText(password));
        Espresso.onView(withId(R.id.confirm)).perform(typeText(confirm));
        Espresso.onView(withId(R.id.phone)).perform(typeText(phone));
        Espresso.closeSoftKeyboard();
        Espresso.onView(withId(R.id.employee)).perform(click());
        // verify activity change
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @Test
    public void hyperLinkTest(){
        Espresso.onView(withId(R.id.activity_main_link)).perform(click());
        // verify activity change
        intended(hasComponent(LoginActivity.class.getName()));
    }

    @Test
    public void existingUserTest(){
        Espresso.onView(withId(R.id.signUp)).perform(click());
        Espresso.onView(withId(R.id.firstName)).perform(typeText(fName));
        Espresso.onView(withId(R.id.lastName)).perform(typeText(lName));
        Espresso.onView(withId(R.id.email)).perform(typeText(email));
        Espresso.onView(withId(R.id.password)).perform(typeText(password));
        Espresso.onView(withId(R.id.confirm)).perform(typeText(confirm));
        Espresso.onView(withId(R.id.phone)).perform(typeText(phone));
        Espresso.closeSoftKeyboard();
        Espresso.onView(withId(R.id.employee)).perform(click());

        intended(hasComponent(SignupActivity.class.getName()));
    }

    @After
    public void tearDown() throws Exception {
        System.gc();
    }
}
