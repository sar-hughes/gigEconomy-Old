package ca.dal.csci3130.quickcash.jobPostings;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;

import android.app.Activity;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.matcher.ViewMatchers;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.action.ViewActions.typeText;


import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

@RunWith(AndroidJUnit4.class)
public class AddJobActivityEspressoTest {

    private String jobTitle = "House Cleaner";
    private String jobDescrip = "In need of a house cleaner for a day";
    private String jobType= "Cleaner";
    private String duration = "8";
    private String salary = "12.50";
    private String startDate = "20/05/2022";
    private String address = "6225 University Ave, Halifax, NS";


    @Rule
    public ActivityScenarioRule<AddJobActivity> AddJobTestRule = new ActivityScenarioRule<AddJobActivity>(AddJobActivity.class);

    @Before
    public void setup() {
        Intents.init();
    }

    @Test
    public void AddValidJobTest(){
        Espresso.onView(withId(R.id.jobTitle)).perform(typeText(jobTitle));
        Espresso.onView(withId(R.id.description)).perform(typeText(jobDescrip));
        Espresso.onView(withId(R.id.jobType)).perform(typeText(jobType));
        Espresso.onView(withId(R.id.duration)).perform(typeText(duration));
        Espresso.onView(withId(R.id.salary)).perform(typeText(salary));
        Espresso.onView(withId(R.id.startDate)).perform(typeText(startDate));
        Espresso.onView(withId(R.id.location)).perform(typeText(address));

        Espresso.onView(withId(R.id.Btn_submit)).perform(click());
        intended(hasComponent(EmployerHomeActivity.class.getName()));

    }

    @Test
    public void AddInvalidJobTest(){
        Espresso.onView(withId(R.id.jobTitle)).perform(typeText(jobTitle));
        Espresso.onView(withId(R.id.description)).perform(typeText(jobDescrip));
        Espresso.onView(withId(R.id.jobType)).perform(typeText(jobType));
        Espresso.onView(withId(R.id.duration)).perform(typeText(duration));
        Espresso.onView(withId(R.id.salary)).perform(typeText(salary));
        Espresso.onView(withId(R.id.startDate)).perform(typeText("tomorrow"));
        Espresso.onView(withId(R.id.location)).perform(typeText(address));

        Espresso.onView(withId(R.id.Btn_submit)).perform(click());
        intended(hasComponent(AddJobActivity.class.getName()));
    }

    @After
    public void tearDown() {
        System.gc();
    }


}
