package ca.dal.csci3130.quickcash.jobPostings;

import org.junit.runner.RunWith;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import ca.dal.csci3130.quickcash.R;

@RunWith(AndroidJUnit4.class)
public class EmployerJobSearchActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<EmployerJobSearchActivity> employerSearchActivityTestRule = new ActivityScenarioRule<EmployerJobSearchActivity>(EmployerJobSearchActivity.class);


    @Before
    public void setUp() {
        Intents.init();
    }

    @Test
    public void checkPage(){
        Espresso.onView(withId(R.id.editTextTextPersonName)).check(matches(withText("Your Posts:")));
    }

    @After
    public void tearDown() throws Exception {
        System.gc();
    }
}
