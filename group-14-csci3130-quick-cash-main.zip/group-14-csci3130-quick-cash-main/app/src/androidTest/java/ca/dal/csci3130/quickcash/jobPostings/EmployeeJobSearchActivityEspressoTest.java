package ca.dal.csci3130.quickcash.jobPostings;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.matcher.ViewMatchers.withId;


import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.usermanagement.SignupActivity;

@RunWith(AndroidJUnit4.class)
public class EmployeeJobSearchActivityEspressoTest {

    @Rule
    public ActivityScenarioRule<EmployeeJobSearchActivity> employeeSearchActivityTestRule = new ActivityScenarioRule<EmployeeJobSearchActivity>(EmployeeJobSearchActivity.class);


    @Before
    public void setUp() {
        Intents.init();
    }

    @Test
    public void checkNoSearch(){
        Espresso.onView(withId(R.id.search_bar)).perform(typeText(""));
        Espresso.onView(withId(R.id.searchButton)).perform(click());
        //nothing happens
    }

    @Test
    public void checkSearch(){
        Espresso.onView(withId(R.id.search_bar)).perform(typeText("cleaner"));
        Espresso.onView(withId(R.id.searchButton)).perform(click());
        // should make relevant job posts appear on map, unsure how to test that
    }

    @After
    public void tearDown() throws Exception {
        System.gc();
    }
}
