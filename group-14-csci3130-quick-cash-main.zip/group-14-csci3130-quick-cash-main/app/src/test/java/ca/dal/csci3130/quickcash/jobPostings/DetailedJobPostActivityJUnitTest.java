package ca.dal.csci3130.quickcash.jobPostings;

public class DetailedJobPostActivityJUnitTest {
}
