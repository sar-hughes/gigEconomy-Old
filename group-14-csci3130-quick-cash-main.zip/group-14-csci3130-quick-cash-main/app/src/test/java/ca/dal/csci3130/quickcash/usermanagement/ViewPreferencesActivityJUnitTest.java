package ca.dal.csci3130.quickcash.usermanagement;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ViewPreferencesActivityJUnitTest {


    @Before
    public void setUpPreferences(){
        ViewPreferencesActivity.jobTypePref = "Driver";
        ViewPreferencesActivity.salaryPref = "15.95/hr-19.95/hr";
        ViewPreferencesActivity.durationPref = "1hr-2hr";
    }

    @Test
    public void testGetJobPos(){
        assertEquals(ViewPreferencesActivity.getJobPos(), 1);
    }

    @Test
    public void testGetSalPos(){
        assertEquals(ViewPreferencesActivity.getSalPos(), 2);
    }

    @Test
    public void testGetDurPos(){
        assertEquals(ViewPreferencesActivity.getDurPos(), 0);
    }
}
