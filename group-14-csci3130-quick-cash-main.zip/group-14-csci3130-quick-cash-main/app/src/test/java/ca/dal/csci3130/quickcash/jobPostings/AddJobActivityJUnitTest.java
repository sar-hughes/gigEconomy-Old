package ca.dal.csci3130.quickcash.jobPostings;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ca.dal.csci3130.quickcash.usermanagement.SignupActivity;

public class AddJobActivityJUnitTest {

    @Test
    public void isTitleEmpty(){
        assertFalse(AddJobActivity.isTitleEmpty("Bob"));
        assertTrue(AddJobActivity.isTitleEmpty(""));
    }
    @Test
    public void isDescriptionEmpty(){
        assertFalse(AddJobActivity.isDescriptionEmpty("This is a description"));
        assertTrue(AddJobActivity.isDescriptionEmpty(""));
    }

    @Test
    public void isTypeEmpty(){
        assertFalse(AddJobActivity.isTypeEmpty("babysitting"));
        assertTrue(AddJobActivity.isTypeEmpty(""));
    }

    @Test
    public void isEmployerEmailEmpty(){
        assertFalse(AddJobActivity.isEmployerEmailEmpty("buisness@gmail.com"));
        assertTrue(AddJobActivity.isEmployerEmailEmpty(""));
    }

    @Test
    public void isAcceptedEmpty(){
        assertFalse(AddJobActivity.isAcceptedEmpty("yes"));
        assertTrue(AddJobActivity.isAcceptedEmpty(""));
    }

    @Test
    public void isApplicantsEmpty(){
        ArrayList<String> test1 = new ArrayList<String>();
        ArrayList<String> test2 = new ArrayList<String>();

        test1.add("Bob");
        test1.add("Anna");
        test1.add("Greg");

        assertFalse(AddJobActivity.isApplicantsEmpty(test1));
        assertTrue(AddJobActivity.isApplicantsEmpty(test2));
    }

    @Test
    public void isTitleValid(){
        assertTrue(AddJobActivity.isValidTitle("Bob"));
    }

    @Test
    public void isSalaryValid() {
        assertTrue(AddJobActivity.isValidSalary(20));
    }

    @Test
    public void isTitleInvalid(){
        assertFalse(AddJobActivity.isValidTitle("Hello!!"));
        assertFalse(AddJobActivity.isValidTitle("12 ways"));
    }

    @Test
    public void isSalaryInvalid(){
        assertFalse(AddJobActivity.isValidSalary(-1));
        assertFalse(AddJobActivity.isValidSalary(-100));
    }

    @Test
    public void isDurationValid(){
        assertTrue(AddJobActivity.isValidDuration(1));
    }

    @Test
    public void isDescriptionValid() {
        assertTrue(AddJobActivity.isValidDescription("This is a valid description"));
    }

    @Test
    public void isDurationInvalid(){
        assertFalse(AddJobActivity.isValidDuration(-100));
        assertFalse(AddJobActivity.isValidDuration(1000000000));
    }
    /*
    *Generated from online Lorem Ipsum
    * MLA:
    * Generated, Random Computer. Lorem Ipsum, 7 Mar. 2022, https://www.lipsum.com/feed/html.
     */
    @Test
    public void isDescriptionInvalid(){
        assertFalse(AddJobActivity.isValidDescription("This is an invalid description" +
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit." +
                " Phasellus fermentum blandit felis, at hendrerit est laoreet nec." +
                " Mauris ut turpis ut enim dapibus mattis. Mauris ornare sem ac sem lacinia auctor." +
                " Aliquam sed orci turpis." +
                " Curabitur fermentum hendrerit elit, ut venenatis lacus lobortis at." +
                " Interdum et malesuada fames ac ante ipsum primis in faucibus." +
                " Aenean placerat, felis ut iaculis ultrices, lorem elit dapibus justo," +
                " a malesuada leo enim vitae dui." +
                " Vivamus tortor erat, faucibus ut varius sed, auctor consequat arcu. " +
                "Curabitur convallis vulputate magna finibus vulputate. Cras vel ultricies arcu." +
                " Maecenas vulputate arcu ac justo commodo finibus." +
                " Etiam facilisis et odio eu laoreet. Vestibulum viverra, orci id venenatis mattis," +
                " tellus lectus commodo lectus, id tempus lorem tortor non sapien. Cras nulla lectus," +
                " varius posuere nunc a, malesuada ultricies lorem."));


    }

    @Test
    public void isStartDateValid() {
        assertTrue(AddJobActivity.isValidStartDate("07/03/2022"));

    }

    @Test
    public void isStartDateInvalid(){
        assertFalse(AddJobActivity.isValidStartDate(""));
        assertFalse(AddJobActivity.isValidStartDate("Hamburger"));
    }

    @Test
    public void isLongitudeValid() {
        assertTrue(AddJobActivity.isValidLongitude(180.00));
        assertTrue(AddJobActivity.isValidLongitude(-180.00));
        assertTrue(AddJobActivity.isValidLongitude(180));
    }

    @Test
    public void isLatitudeValid() {
        assertTrue(AddJobActivity.isValidLatitude(90.00));
        assertTrue(AddJobActivity.isValidLatitude(-90.00));
        assertTrue(AddJobActivity.isValidLatitude(90));

    }

    @Test
    public void isLongitudeInvalid(){
        assertFalse(AddJobActivity.isValidLongitude(181.00));
        assertFalse(AddJobActivity.isValidLongitude(-181.00));
        assertFalse(AddJobActivity.isValidLongitude(-181));
    }

    @Test
    public void isLatitudeInvalid(){
        assertFalse(AddJobActivity.isValidLatitude(91.00));
        assertFalse(AddJobActivity.isValidLatitude(-91.00));
        assertFalse(AddJobActivity.isValidLatitude(-91));
    }

    @Test
    public void isTypeValid() {
        assertTrue(AddJobActivity.isValidType("babysitting"));
    }

    @Test
    public void isNumJobsValid() {
        assertTrue(AddJobActivity.isValidNumJobs(10.00));
    }

    @Test
    public void isTypeInvalid(){
        assertFalse(AddJobActivity.isValidType(""));
    }

    @Test
    public void isNumJobsInvalid(){
        assertFalse(AddJobActivity.isValidNumJobs(-1.00));
    }

    @Test
    public void isJobIDValid() {
        assertTrue(AddJobActivity.isValidJobID(1.00));
    }

    @Test
    public void isEmployerEmailValid() {
        assertTrue(AddJobActivity.isValidEmployerEmail("test1@gmail.com"));
        assertTrue(AddJobActivity.isValidEmployerEmail("test2@outlook.com"));

    }

    @Test
    public void isJobIdInvalid(){
        assertFalse(AddJobActivity.isValidJobID(-1));
    }

    @Test
    public void isEmployerEmailInvalid(){
        assertFalse(AddJobActivity.isValidEmployerEmail("Joe"));
        assertFalse(AddJobActivity.isValidEmployerEmail("Joe@"));

    }

    @Test
    public void isApplicantsValid() {
        ArrayList<String> test1 = new ArrayList<String>();

        test1.add("Bob");
        test1.add("Anna");
        test1.add("Greg");
        assertTrue(AddJobActivity.isValidApplicants(test1));
    }

    @Test
    public void isAcceptedValid() {
        assertTrue(AddJobActivity.isValidAccepted("yes"));
        assertTrue(AddJobActivity.isValidAccepted("no"));

    }

    @Test
    public void isApplicantsInvalid(){
        ArrayList<String> test1 = new ArrayList<String>();
        ArrayList<String> test2 = new ArrayList<String>();

        test1.add("");
        test1.add("");
        test1.add("");
        assertFalse(AddJobActivity.isValidApplicants(test1));
        assertFalse(AddJobActivity.isValidApplicants(test2));
    }

    @Test
    public void isAcceptedInvalid(){
        assertFalse(AddJobActivity.isValidAccepted("okay"));
        assertFalse(AddJobActivity.isValidAccepted("not okay"));

    }

    @Test
    public void multipleWordTitle(){
        assertTrue(AddJobActivity.isValidTitle("Security Guard"));
        assertTrue(AddJobActivity.isValidTitle("duck walking in a straight line"));
        assertTrue(AddJobActivity.isValidTitle("Teacher's Assistant"));
    }


}
