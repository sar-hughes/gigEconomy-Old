package ca.dal.csci3130.quickcash.usermanagement;

import org.junit.Test;
import static org.junit.Assert.*;

public class SignupActivityJUnitTest {

    @Test
    public void isFirstNameEmpty(){
        assertFalse(SignupActivity.isFirstNameEmpty("Bob"));
        assertTrue(SignupActivity.isFirstNameEmpty(""));
    }

    @Test
    public void isLastNameEmpty(){
        assertFalse(SignupActivity.isLastNameEmpty("Joe"));
        assertTrue(SignupActivity.isLastNameEmpty(""));
    }

    @Test
    public void isFirstNameValid(){
        assertTrue(SignupActivity.isValidFirstName("Bob"));
    }

    @Test
    public void isLastNameValid(){
        assertTrue(SignupActivity.isValidLastName("Joe"));
    }

    @Test
    public void isLastNameInvalid(){
        assertFalse(SignupActivity.isValidLastName("Hello!!"));
        assertFalse(SignupActivity.isValidLastName("12 ways"));
    }

    @Test
    public void isFirstNameInvalid(){
        assertFalse(SignupActivity.isValidFirstName("The@@rock!"));
        assertFalse(SignupActivity.isValidFirstName("123miss"));
    }

    @Test
    public void isPasswordEmpty(){
        assertFalse(SignupActivity.isPasswordEmpty("bjjev34673g!"));
        assertTrue(SignupActivity.isPasswordEmpty(""));
    }

    @Test
    public void isConfirmEmpty(){
        assertFalse(SignupActivity.isConfirmPasswordEmpty("cberyf23?"));
        assertTrue(SignupActivity.isConfirmPasswordEmpty(""));
    }

    @Test
    public void isPasswordValid(){
        assertTrue(SignupActivity.isValidPassword("fbAer3785!."));

    }

    @Test
    public void isPasswordInvalid(){
        assertFalse(SignupActivity.isValidPassword("hi3"));
        assertFalse(SignupActivity.isValidPassword("helloitsme"));
    }

    @Test
    public void isConfirmCorrect(){
        assertTrue(SignupActivity.isConfirmCorrect("Hello123!", "Hello123!"));
        assertFalse(SignupActivity.isConfirmCorrect("Hello123!", "Hiii20004!"));
    }

    @Test
    public void isEmailEmpty(){
        assertFalse(SignupActivity.isEmailEmpty("bobjoe@dal.ca"));
        assertTrue(SignupActivity.isEmailEmpty(""));
    }

    @Test
    public void isEmailValid(){
        assertTrue(SignupActivity.isValidEmail("bob.joe@dal.ca"));
    }

    @Test
    public void isEmailInvalid(){
        assertFalse(SignupActivity.isValidEmail("bobjoe.com"));
        assertFalse(SignupActivity.isValidEmail("bob@dal@dal"));
    }

    @Test
    public void isPhoneEmpty(){
        assertFalse(SignupActivity.isPhoneEmpty("9025682943"));
        assertTrue(SignupActivity.isPhoneEmpty(""));
    }

    @Test
    public void isPhoneValid(){
        assertTrue(SignupActivity.isValidPhone("9025682943"));
    }

    @Test
    public void isPhoneInvalid(){
        assertFalse(SignupActivity.isValidPhone("463474"));
        assertFalse(SignupActivity.isValidPhone("hi2455684567"));
    }

    @Test
    public void isUserTypeChosen(){
        assertTrue(SignupActivity.chosenUserType("employee"));
        assertTrue(SignupActivity.chosenUserType("employer"));
        assertFalse(SignupActivity.chosenUserType(""));
    }

}
