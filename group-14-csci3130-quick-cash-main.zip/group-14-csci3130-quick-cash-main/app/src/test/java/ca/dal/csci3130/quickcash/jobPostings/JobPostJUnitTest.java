package ca.dal.csci3130.quickcash.jobPostings;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JobPostJUnitTest {
    static JobPost post, post2;
    static Date date = null;

    @BeforeClass
    public static void createJob() throws Exception{

        try {
            date = new SimpleDateFormat("dd/MM/yyyy").parse("02/04/2022");
        } catch (ParseException e) {
            e.printStackTrace();
        }

        post = new JobPost("easy babysitting kids", 55, 5, "Taking care of 2 preteens for a few hours each week.", date,90.00,-30.00, "babysitting", "bobarnold@gmail.com");
        post2 = new JobPost("washing 2 cars", 20, 3, "Wash a couple of cars.", date,85.00,45.00, "carwash", "bobarnold@gmail.com");
    }

    @Test
    public void testTitle(){
        assertEquals("easy babysitting kids", post.getTitle());
    }

    @Test
    public void testSalary(){
        float salary = 55;
        assertEquals(salary, post.getSalary(),0.009);
    }

    @Test
    public void testDuration(){
        assertEquals(5, post.getDuration());
    }

    @Test
    public void testDescription(){
        assertEquals("Taking care of 2 preteens for a few hours each week.", post.getDescription());
    }

    @Test
    public void testStartDate(){
        assertEquals(date, post.getStartDate());
    }

    @Test
    public void testLongitude(){
        double lng = 90.0;
        assertEquals(lng, post.getLongitude(),0.05);
    }

    @Test
    public void testLatitude(){
        double lat = -30.0;
        assertEquals(lat, post.getLatitude(), 0.05);
    }

    @Test
    public void testType(){
        assertEquals("babysitting", post.getType());
    }

    @Test
    public void testEmail(){
        assertEquals("bobarnold@gmail.com", post.getEmployerEmail());
    }

    @Test
    public void testJobNumber(){
        assertEquals(2, post.getNumJobs());
    }





}
