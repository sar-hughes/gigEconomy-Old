package ca.dal.csci3130.quickcash.usermanagement;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class LoginActivityJUnitTest {

    @Test
    public void testIsEmptyEmail(){
        assertFalse(SignupActivity.isEmailEmpty("bobjoe@dal.ca"));
        assertTrue(SignupActivity.isEmailEmpty(""));
    }

    @Test
    public void testIsEmptyPassword(){
        assertFalse(SignupActivity.isPasswordEmpty("bjjev34673g!"));
        assertTrue(SignupActivity.isPasswordEmpty(""));
    }
}
