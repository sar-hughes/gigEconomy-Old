package ca.dal.csci3130.quickcash.jobPostings;

import java.util.*;

public interface JobPostInterface {

    String getTitle();

    void setTitle(String title);

    float getSalary();

    void setSalary(float salary);

    int getDuration();

    void setDuration(int duration);

    String getDescription();

    void setDescription(String description);

    Date getStartDate();

    void setStartDate(Date startDate);

    double getLongitude();

    void setLongitude(Double longitude);

    double getLatitude();

    void setLatitude(Double latitude);

    String getType();

    void setType(String type);

    int getNumJobs();

    int getJobID();

    String getEmployerEmail();

    void setEmployerEmail(String email);

    ArrayList<String> getApplicants();

    void setApplicants(ArrayList<String> applicants);

    String getAccepted();

    void setAccepted(String accepted);
}
