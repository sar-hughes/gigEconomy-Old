package ca.dal.csci3130.quickcash.usermanagement;

public interface SessionManagerInterface {

    void createLoginSession(String email, String password, String firstName, String lastName, String userType);

    void checkLogin();

    void logoutUser();

    boolean isLoggedIn();

    String getKeyName();

    String getKeyLastName();

    String getKeyEmail();
}
