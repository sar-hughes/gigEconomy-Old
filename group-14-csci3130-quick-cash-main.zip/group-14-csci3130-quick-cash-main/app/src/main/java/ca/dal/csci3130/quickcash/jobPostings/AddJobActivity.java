package ca.dal.csci3130.quickcash.jobPostings;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.database.DatabaseReference;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.SessionManager;
import ca.dal.csci3130.quickcash.usermanagement.SignupActivity;
import ca.dal.csci3130.quickcash.usermanagement.UserDAO;

public class AddJobActivity extends AppCompatActivity {

    // variables here
    DatabaseReference jobstable = null;
    AddJobDAO addJobDAO;


    /**
     * onCreate method for AddJobActivity
     * @param savedInstanceState Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job);
        addJobDAO = new AddJobDAO();
        jobstable = addJobDAO.getDatabaseReference();


        // do stuff
        Button submitJob = (Button) findViewById(R.id.Btn_submit);
        submitJob.setOnClickListener(view -> addJob());

    }

    /**
     * method for checking if job post credentials entered are valid
     * @param title String
     * @param salary float
     * @param duration int
     * @param description String
     * @param startDate String
     * @param longitude double
     * @param latitude double
     * @param address String
     * @param type String
     * @param employerEmail String
     * @return boolean
     */
    public boolean isValidJobPost(String title, float salary, int duration, String description, String startDate, double longitude, double latitude, String address, String type, String employerEmail){
        if(isTitleEmpty(title)){
            Toast.makeText(getApplicationContext(), "Enter Title!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidTitle(title)){
            Toast.makeText(getApplicationContext(), "Enter Valid Title!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(!isValidSalary(salary)){
            Toast.makeText(getApplicationContext(), "Enter Valid Salary!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidDuration(duration)){
            Toast.makeText(getApplicationContext(), "Enter Valid Duration!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(isDescriptionEmpty(description)){
            Toast.makeText(getApplicationContext(), "Enter Description!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidDescription(description)){
            Toast.makeText(getApplicationContext(), "Enter Valid Description!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(isStartDateEmpty(startDate)){
            Toast.makeText(getApplicationContext(), "Enter Start Date!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidStartDate(startDate)){
            Toast.makeText(getApplicationContext(), "Enter Valid Start Date in format dd/MM/yyyy!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(!isValidLatitude(latitude)){
            Toast.makeText(getApplicationContext(), "Enter Valid Latitude!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidLongitude(longitude)){
            Toast.makeText(getApplicationContext(), "Enter Valid Longitude!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isTypeEmpty(type)){
            Toast.makeText(getApplicationContext(), "Enter Type!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(isDurationEmpty(duration)){
            Toast.makeText(getApplicationContext(), "Enter Duration!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isSalaryEmpty(salary)){
            Toast.makeText(getApplicationContext(), "Enter Salary!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidType(type)){
            Toast.makeText(getApplicationContext(), "Enter Valid Type!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isAddressEmpty(address)){
            Toast.makeText(getApplicationContext(), "Enter the Address", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidEmployerEmail(employerEmail)){
            Toast.makeText(getApplicationContext(), "Enter Valid Email!", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * method to get coordinates from string address
     * @param strAddress String
     * @return LatLng
     */
    public LatLng findLocationFromAddress(String strAddress) {
        Geocoder coder = new Geocoder(this);
        List<Address> address;
        LatLng latLng = null;

        try {
            //Get latLng from String
            address = coder.getFromLocationName(strAddress, 5);

            //check for null
            if (address != null) {

                try {
                    Address location = address.get(0);
                    latLng = new LatLng(location.getLatitude(), location.getLongitude());

                } catch (IndexOutOfBoundsException er) {
                    Toast.makeText(this, "Location isn't available", Toast.LENGTH_SHORT).show();
                }

            }


        } catch (IOException e) {
            e.printStackTrace();
        }
        return latLng;
    }




        //validation methods

    protected static boolean isTitleEmpty(String title){
        return title.isEmpty();
    }

    protected static boolean isDescriptionEmpty(String description){
        return description.isEmpty();
    }

    protected static boolean isTypeEmpty(String type){
        return type.isEmpty();
    }

    protected static boolean isStartDateEmpty(String startDate){
        return startDate.isEmpty();
    }
    protected static boolean isDurationEmpty(int duration){
        String dur = String.valueOf(duration);
        return dur.isEmpty();
    }
    protected static boolean isSalaryEmpty(float salary){
        String sal = String.valueOf(salary);
        return sal.isEmpty();
    }

    protected static boolean isEmployerEmailEmpty(String employerEmail){
        return employerEmail.isEmpty();
    }

    protected static boolean isAcceptedEmpty(String accepted){
        return accepted.isEmpty();
    }

    protected static boolean isApplicantsEmpty(ArrayList<String> applicants){
        return applicants.isEmpty();
    }
    protected static boolean isAddressEmpty(String Address){
        return Address.isEmpty();
    }

    protected static boolean isValidTitle(String title){
        return title.matches("([A-Za-z ])+'?[A-Za-z ]*$");
    }

    protected static boolean isValidSalary(float salary){
        return (salary > 0.00);
    }

    protected static boolean isValidDuration(int duration){
        return (duration > 0) && (duration < 1000000);
    }

    protected static boolean isValidDescription(String description){
         return description.length() < 240;
    }

    protected static boolean isValidStartDate(String startDate){
        if (startDate.trim().equals(""))
        {
            return false;
        }
        else {


            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            format.setLenient(false);
            try {
                 Date javaDate = format.parse(startDate);
                return true;
            }
             catch (ParseException e) {
                return false;
            }
        }
    }

    /**
     * method to convert string date in form dd/MM/yyy to Date object
     * @param startDate String
     * @return Date
     */
    protected Date convertToDate(String startDate){
        Date newDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try{
            newDate = format.parse(startDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return newDate;
    }

    protected static boolean isValidLongitude(double longitude){
        return (longitude >= -180.00) && (longitude <= 180.00);
    }
    protected static boolean isValidLatitude(double latitude){
        return (latitude >= -90.00) && (latitude <= 90.00);
    }



    protected static boolean isValidType(String type){
        return type.matches("([A-Za-z])+");
    }

    //may need to change, not sure exactly numJobs needs to be
    protected static boolean isValidNumJobs(double numJobs){
        return (numJobs > 0.00);
    }

    //may need to change, not sure exactly jobID needs to be
    protected static boolean isValidJobID(double jobID){
        return (jobID > 0.00);
    }

    protected static boolean isValidEmployerEmail(String employerEmail){
        return employerEmail.matches("^\\S+@\\S+\\.[A-Za-z]+$");
    }

    protected static boolean isValidApplicants(ArrayList<String> applicants){
        boolean flag = false;
        for(int i = 0; i < applicants.size(); i++){
            String currentApplicant = applicants.get(i);
            flag = currentApplicant.matches("([A-Za-z])+");
        }
        return flag;
    }

    protected static boolean isValidAccepted(String accepted){

        return (accepted.equals("yes") || accepted.equals("no"));
    }

    /**
     * method to add job to database if credentials are valid
     */
    private void addJob(){
        // first get credentials

        EditText title = (EditText)findViewById(R.id.jobTitle);
        String jobTitle = title.getText().toString().trim();

        EditText description = (EditText)findViewById(R.id.description);
        String jobDescription = description.getText().toString().trim();

        EditText jobtype = (EditText)findViewById(R.id.jobType);
        String jobType = jobtype.getText().toString().trim();

        EditText duration = (EditText)findViewById(R.id.duration);
        int jobDuration = Integer.parseInt(duration.getText().toString().trim());

        EditText salary = (EditText)findViewById(R.id.salary);
        float jobSalary = Float.parseFloat(salary.getText().toString().trim());

        EditText startDate = (EditText)findViewById(R.id.startDate);
        String jobStartDate = startDate.getText().toString().trim();

        Context context = getApplicationContext();
        SessionManager newSession = new SessionManager(context);
        String jobEmail = newSession.getKeyEmail();

        EditText address = (EditText)findViewById(R.id.location);
        String jobAddress = address.getText().toString().trim();

        LatLng locationPoints = findLocationFromAddress(jobAddress);
        double latitude = locationPoints.latitude;
        double longitude = locationPoints.longitude;

        //check valid details
        if(!isValidJobPost(jobTitle, jobSalary, jobDuration, jobDescription, jobStartDate, longitude, latitude, jobAddress,jobType, jobEmail)){
            return;
        }
        Date dateStartDate = convertToDate(jobStartDate);

        // add to database
        JobPost newJobPost = new JobPost(jobTitle, jobSalary, jobDuration, jobDescription, dateStartDate, longitude, latitude,jobType, jobEmail);
        AddJobDAO jobdao = new AddJobDAO();
        jobdao.add(newJobPost);
        Intent viewIntent = new Intent(AddJobActivity.this, EmployerHomeActivity.class);
        startActivity(viewIntent);

    }


}

