package ca.dal.csci3130.quickcash.jobPostings;

import android.content.Context;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import ca.dal.csci3130.quickcash.common.AbstractDAO;
import ca.dal.csci3130.quickcash.common.Constants;
import ca.dal.csci3130.quickcash.usermanagement.User;
import ca.dal.csci3130.quickcash.usermanagement.UserInterface;

public class JobDAO extends AbstractDAO {
    private final DatabaseReference databaseReference;

    /**
     * User database object constructor
     */
    public JobDAO(Context context) {
        // FIREBASE_URL needs to be updated
        FirebaseDatabase db = FirebaseDatabase.getInstance(Constants.FIREBASE_URL);
        databaseReference = db.getReference(JobPost.class.getSimpleName());
    }

    /**
     *
     * @return reference to the database
     */
    @Override
    public DatabaseReference getDatabaseReference() {
        return databaseReference;
    }

    /**
     * Takes a user object and pushes it to the database
     * @param user
     * @return
     */
    @Override
    public Task<Void> add(UserInterface user) {
        return databaseReference.push().setValue(user);
    }

}
