package ca.dal.csci3130.quickcash;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.SignupActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Add logic to handle the two buttons added in the UI
        Button login = (Button)findViewById(R.id.resultBtn);
        Button signup = (Button)findViewById(R.id.signUp);

        login.setOnClickListener(this);

        signup.setOnClickListener(this);
    }

    /**
     * onClick method for both buttons
     * @param view View
     */
    @Override
    public void onClick(View view) {
        //for login button
        if(R.id.resultBtn == view.getId()){
            Intent viewIntent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(viewIntent);
        }
        //for signup
        else if(R.id.signUp == view.getId()){
            Intent viewIntent = new Intent(MainActivity.this, SignupActivity.class);
            startActivity(viewIntent);
        }
    }
    /**
     * Method to disable the back button. Tells User and returns
     */
    @Override
    public void onBackPressed(){
        Toast.makeText(getApplicationContext(), "Can not go back", Toast.LENGTH_SHORT).show();
    }

}