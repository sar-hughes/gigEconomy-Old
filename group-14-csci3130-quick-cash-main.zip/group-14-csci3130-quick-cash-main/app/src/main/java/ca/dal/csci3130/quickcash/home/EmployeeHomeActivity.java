package ca.dal.csci3130.quickcash.home;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.Serializable;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.jobPostings.EmployeeJobSearchActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.SessionManager;
import ca.dal.csci3130.quickcash.usermanagement.ViewPreferencesActivity;

@RequiresApi(api = Build.VERSION_CODES.N)
public class EmployeeHomeActivity extends AppCompatActivity implements Serializable, View.OnClickListener {

    String email;
    SessionManager newSession;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_home);
        Context context = getApplicationContext();
        newSession = new SessionManager(context);
        String fName = newSession.getKeyName();
        String lName = newSession.getKeyLastName();


        // display welcome message to user
        TextView topTextView = (TextView) findViewById(R.id.topTextView);
        topTextView.setText("Welcome Employee "+fName+" "+lName);

        // button function for logout
        Button employeeLogout = (Button) findViewById(R.id.EmployeeLogoutButton);
        employeeLogout.setOnClickListener(this);

        // button function for search postings
        Button searchPostingsBtn = (Button) findViewById(R.id.search_button);
        searchPostingsBtn.setOnClickListener(this);

        //set email to send to viewPreferences activity
        email = newSession.getKeyEmail();

        // button function for view preferences
        Button viewPrefBtn = (Button) findViewById(R.id.viewPreferences);
        viewPrefBtn.setOnClickListener(this);
        

    }

    /**
     * onClick method for buttons
     * @param view
     */
    @Override
    public void onClick(View view) {
        //for logout
        if(view.getId() == R.id.EmployeeLogoutButton) {
            //Clear shared preferences of employee user
            newSession.logoutUser();

            //Redirect user to login screen
            Intent viewIntent = new Intent(EmployeeHomeActivity.this, LoginActivity.class);
            startActivity(viewIntent);
        }
        else if(view.getId() == R.id.search_button) {
            //for search postings
            Intent viewIntent = new Intent(EmployeeHomeActivity.this, EmployeeJobSearchActivity.class);
            startActivity(viewIntent);
        }

        else if(view.getId() == R.id.viewPreferences) {
            // for preference activity
            Intent viewIntent = new Intent(EmployeeHomeActivity.this, ViewPreferencesActivity.class);
            viewIntent.putExtra("email", email);
            startActivity(viewIntent);
        }
    }

    /*prevent the user from going back to login when the back button is pressed*/

    /**
     * Method to disable the back button. Tells User and returns
     */
    @Override
    public void onBackPressed(){
        Toast.makeText(getApplicationContext(),"Cannot go back", Toast.LENGTH_SHORT).show();
    }
}