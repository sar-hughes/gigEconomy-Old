package ca.dal.csci3130.quickcash.usermanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.common.Utils;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

public class  SignupActivity extends AppCompatActivity implements View.OnClickListener {
    DatabaseReference userstable = null;
    UserDAO userDAO;


    /**
     * method to check if the user is already registered with that email
     * @param newUser newUser
     * @return boolean
     */
    public boolean isRegistered(User newUser){
        //ET4: Check if the database contains a value with the input details to see if the user is registered
        final boolean[] error = {false};
        userstable.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                String email = newUser.getEmail();

                for(DataSnapshot users : snapshot.getChildren())
                {
                    if(users.child(email).exists())
                    {
                        error[0] = true;
                        Toast.makeText(getApplicationContext(), "this email already exists", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        error[0] = false;
                        //Add user to database
                    }
                }
            }

            /**
             * Cancel method for if there is an error
             * The user is not pushed to the database
             * @param error
             */
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // on cancelled do nothing
            }

        });

        return error[0];
    }

    /**
     * onCreate method for SignUpActivity
     * @param savedInstanceState savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Button submit = (Button)findViewById(R.id.Btn_Login);
        userDAO = new UserDAO();
        userstable = userDAO.getDatabaseReference();
        // Add logic for signup
        //hyperlink redirection
        TextView hyperlink = (TextView) findViewById(R.id.activity_main_link);
        hyperlink.setOnClickListener(this);
        //submit button function
        submit.setOnClickListener(this);


    }

    /**
     * method to check if credentials are valid
     * @param firstName firstName
     * @param lastName lastName
     * @param Email email
     * @param phoneNumber phoneNumber
     * @param password password
     * @param confirmPassword confirmPassword
     * @param role role
     * @return boolean
     */
    public boolean isValidCreds(String firstName, String lastName, String Email, String phoneNumber, String password, String confirmPassword, String role){

        if(isFirstNameEmpty(firstName)){
            Toast.makeText(getApplicationContext(), "Enter First Name!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidFirstName(firstName)){
            Toast.makeText(getApplicationContext(), "Enter Valid First Name!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isLastNameEmpty(lastName)){
            Toast.makeText(getApplicationContext(), "Enter Last Name!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidLastName(lastName)){
            Toast.makeText(getApplicationContext(), "Enter Valid Last Name!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(isEmailEmpty(Email)){
            Toast.makeText(getApplicationContext(), "Enter Email Name!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidEmail(Email)){
            Toast.makeText(getApplicationContext(), "Enter Valid Email!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(isPhoneEmpty(phoneNumber)){
            Toast.makeText(getApplicationContext(), "Enter Phone Number!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidPhone(phoneNumber)){
            Toast.makeText(getApplicationContext(), "Enter Valid Phone Number!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isPasswordEmpty(password)){
            Toast.makeText(getApplicationContext(), "Enter Password!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isValidPassword(password)){
            Toast.makeText(getApplicationContext(), "Enter Valid Password!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(isConfirmPasswordEmpty(confirmPassword)){
            Toast.makeText(getApplicationContext(), "Enter Password Again!", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(!isConfirmCorrect(password, confirmPassword)){
            Toast.makeText(getApplicationContext(), "Make Sure Passwords Match!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if(!chosenUserType(role)){
            Toast.makeText(getApplicationContext(), "Choose a usertype!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    /**
     * disable back button
     */
    @Override
    public void onBackPressed(){
        Toast.makeText(getApplicationContext(), "Can not go back", Toast.LENGTH_SHORT).show();
    }

    // validation methods

    /**
     * check if first name is empty
     * @param firstName firstName
     * @return boolean
     */
    protected static boolean isFirstNameEmpty(String firstName){
        return firstName.isEmpty();
    }

    /**
     *
     * @param lastName lastName
     * @return boolean
     */
    protected static boolean isLastNameEmpty(String lastName){
        return lastName.isEmpty();
    }

    /**
     *
     * @param password password
     * @return boolean
     */
    protected static boolean isPasswordEmpty(String password){
        return password.isEmpty();
    }

    /**
     *
     * @param confirm confirm
     * @return boolean
     */
    protected static boolean isConfirmPasswordEmpty(String confirm){
        return confirm.isEmpty();
    }

    /**
     *
     * @param email email
     * @return boolean
     */
    protected static boolean isEmailEmpty(String email){
        return email.isEmpty();
    }

    /**
     *
     * @param phoneNum phoneNum
     * @return boolean
     */
    protected static boolean isPhoneEmpty(String phoneNum){
        return phoneNum.isEmpty();
    }

    /**
     *
     * @param first first
     * @return boolean
     */
    protected static boolean isValidFirstName(String first){
        return first.matches("([A-Za-z])+");
    }

    /**
     *
     * @param last last
     * @return boolean
     */
    protected static boolean isValidLastName(String last){
        return last.matches("([A-Za-z])+");
    }

    /**
     *
     * @param password password
     * @return boolean
     */
    protected static boolean isValidPassword(String password){
        return (password.matches(".*[A-Z]+.*[a-z]+.*[0-9]+.*") && password.length() >7);
    }

    /**
     * check if password matches confirm password
     * @param password password
     * @param confirm confirm
     * @return boolean
     */
    protected static boolean isConfirmCorrect(String password, String confirm){
        return confirm.equals(password);
    }

    /**
     *
     * @param email email
     * @return boolean
     */
    protected static boolean isValidEmail(String email){
        return email.matches("^\\S+@\\S+\\.[A-Za-z]+$");
    }

    /**
     *
     * @param phoneNum phoneNum
     * @return boolean
     */
    protected static boolean isValidPhone(String phoneNum){
        return (phoneNum.matches("[0-9]+") && phoneNum.length() == 10);
    }

    /**
     *
     * @param userType userType
     * @return boolean
     */
    protected static boolean chosenUserType(String userType){

        return (userType.equals("employee") || userType.equals("employer"));
    }


    public void onRadioButtonClicked(View view) {
        //necessary method for radiobutton use
    }

    /**
     * Onclick of the submit button.
     * Takes the Users info from the Edit Text fields
     * If user has entered no data, or entered data incorrectly,
     * a message to the user is displayed
     * Creates a User object
     * Creates a UserDAO object
     * Pushes user to database
     *
     */
    private void submitPressed() {
        RadioButton employee =(RadioButton)findViewById(R.id.employee);
        RadioButton employer =(RadioButton)findViewById(R.id.employer);

        EditText fname = (EditText)findViewById(R.id.firstName);
        String firstName = fname.getText().toString().trim();

        EditText lname = (EditText)findViewById(R.id.lastName);
        String lastName = lname.getText().toString().trim();

        EditText email = (EditText)findViewById(R.id.email);
        String emailString = email.getText().toString().trim();

        EditText phone = (EditText)findViewById(R.id.phone);
        String phoneNumber = phone.getText().toString().trim();

        EditText psswrd = (EditText)findViewById(R.id.password);
        String password = psswrd.getText().toString().trim();

        EditText confirmPsswrd = (EditText)findViewById(R.id.confirm);
        String confirmPassword  = confirmPsswrd.getText().toString().trim();

        //needs to be changed
        //bug with
        String role = "";
        if(employee.isChecked()){
            role = "employee";
        }
        if (employer.isChecked()){
            role = "employer";
        }

        if(!isValidCreds(firstName, lastName, emailString, phoneNumber, password, confirmPassword, role)){
            return;
        }


        User newUser = new User(firstName, lastName, emailString, phoneNumber, password, confirmPassword, role);

        if(!isRegistered(newUser))
        {
            String encryptedPass = Utils.EncryptingPassword(password);
            String encryptedConfirm = Utils.EncryptingPassword(confirmPassword);
            newUser.setPassword(encryptedPass);
            newUser.setConfirmPassword(encryptedConfirm);
            UserDAO dao = new UserDAO();
            dao.add(newUser);
            Intent viewIntent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(viewIntent);
        }

    }

    /**
     * onClick for all buttons
     * @param view view
     */
    @Override
    public void onClick(View view) {
    // for hyperlink
        if(view.getId() == R.id.activity_main_link) {
            Intent viewIntent = new Intent(SignupActivity.this, LoginActivity.class);
            startActivity(viewIntent);
        }
        else if(view.getId()== R.id.Btn_Login){
            submitPressed();
        }
    }
}
