package ca.dal.csci3130.quickcash.jobPostings;

import android.Manifest;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.CaseMap;
import android.icu.text.DateFormat;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;

import com.google.android.gms.location.LocationAvailability;

import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import ca.dal.csci3130.quickcash.R;

import ca.dal.csci3130.quickcash.common.Constants;

import com.google.firebase.database.ValueEventListener;

import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.UserDAO;


public class EmployeeJobSearchActivity extends FragmentActivity implements OnMapReadyCallback,
                                                                            Serializable,
                                                                            ActivityCompat.OnRequestPermissionsResultCallback {

    private transient GoogleMap map;
    private transient DatabaseReference databaseReference;
    private boolean noJobsFound = true;
    private transient Location lastKnownLocation;
    private static final int DEFAULT_ZOOM = 15;
    private final transient LatLng defaultLocation = new LatLng(44.637411, -63.587315);
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 3130;
    private JobPost jobPost;
    private static int requestCode;
    private Marker marker;

    /**
     * method for getting the search key work
     * @return String search keywords
     */
    protected String getSearchText() {
        AutoCompleteTextView jobSearch = findViewById(R.id.searchBar);
        return jobSearch.getText().toString().trim();
    }

    /**
     * on create method for employee job search activity
     * @param savedInstanceState Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_search);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);

        // set up the Google map
        setUpMap();

        FirebaseDatabase db = FirebaseDatabase.getInstance(Constants.FIREBASE_URL);
        databaseReference = db.getReference(AddJobActivity.class.getSimpleName());

        String[] province = getResources().getStringArray(R.array.jobs);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_dropdown_item_1line, province);
        AutoCompleteTextView act = (AutoCompleteTextView) findViewById(R.id.searchBar);
        act.setAdapter(adapter);

        // search button function
        Button searchButton = (Button) findViewById(R.id.searchButton);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String jobName = getSearchText();

                InputMethodManager keyboardCloser = (InputMethodManager)
                        getSystemService(Context.INPUT_METHOD_SERVICE);

                keyboardCloser.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                        InputMethodManager.HIDE_NOT_ALWAYS);
                if (jobName.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please enter search term", Toast.LENGTH_SHORT).show();
                }
                else {
                    searchJob(jobName);
                }
                noJobsFound = true;
            }
        });
    }

    //ET4:After enter is clicked, display the corresponding job postings in the search activity
    // frontend on the map centered to the employees location,
    // if there are no postings with the keyword, display a message saying no postings found.

    //ET3: When a keyword/s is typed in the search bar and enter is clicked, make a method to
    // search the database for any job postings with the keyword in the title/ salary/ duration/ description

    /**
     * method to search the database for any matching jobs with the keyword
     * @param jobName String
     */
    public void searchJob(String jobName) {

        databaseReference.addValueEventListener(new ValueEventListener() {

            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot: snapshot.getChildren()) {

                    if (Boolean.TRUE.equals(checkForSearchTerm(dataSnapshot, jobName))) {
                        //we find a job update ui
                        //ET4:display the corresponding job postings in the search activity frontend on
                        // the map centered to the employees location
                        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
                            float[] distance = new float[1];
                            Location.distanceBetween((Double)dataSnapshot.child("latitude").getValue(),
                                    (Double)dataSnapshot.child("longitude").getValue(),
                                    lastKnownLocation.getLatitude(), lastKnownLocation.getLongitude(), distance);

                            if (distance[0] < 10000) {
                                makeJobMarker(dataSnapshot);
                                noJobsFound = false;
                                map.moveCamera(CameraUpdateFactory.newLatLng(marker.getPosition()));
                            }
                        } else {
                            makeJobMarker(dataSnapshot);
                            noJobsFound = false;
                        }
                    }
                }
                if (noJobsFound)
                    Toast.makeText(getApplicationContext(), "No jobs found", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Getting Post failed, log a message
            }
        });
    }

    /**
     * method for setting up the Google map
     */
    private void setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {android.Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
        else {
            requestCode = LOCATION_PERMISSION_REQUEST_CODE;
        }
    }

    /**
     * method to initiate map set up
     * @param googleMap
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        // here the map is set at zoom level 10 (City view)
        CameraUpdateFactory.zoomTo(10);
        //here markers can be added

        databaseReference.addValueEventListener(new ValueEventListener() {
            /**
             * @param snapshot
             */
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               for (DataSnapshot dataSnapshot: snapshot.getChildren()) {
                   makeJobMarker(dataSnapshot);
               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error loading job postings",
                        Toast.LENGTH_SHORT).show();
            }
        });

        //if location permission granted, go to current location, if not go to default location
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            setLocationMap();
        } else {
            setDefaultMap();
        }
    }

    /**
     * method for setting the view location on the map
     */
    public void setLocationMap(){
        map.setMyLocationEnabled(true);
        FusedLocationProviderClient fusedLocationProviderClient =
                LocationServices.getFusedLocationProviderClient(this);
        Task<Location> locationResult = fusedLocationProviderClient.getLastLocation();
        locationResult.addOnCompleteListener(this, task -> {
            if (task.isSuccessful()) {
                // Set the map's camera position to the current location of the device.
                lastKnownLocation = task.getResult();
                if (lastKnownLocation != null) {
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                            new LatLng(lastKnownLocation.getLatitude(),
                                    lastKnownLocation.getLongitude()), DEFAULT_ZOOM));
                }
            }
        });
    }

    /**
     * method for adding a new marker representing a new job on the map
     * @param dataSnapshot DataSnapshot
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void makeJobMarker(DataSnapshot dataSnapshot) {

        makeJobObject(dataSnapshot);

        LatLng jobLocation = new LatLng(jobPost.getLatitude(), jobPost.getLongitude());

        Marker marker = map.addMarker(new MarkerOptions()
                .position(jobLocation)
                .title(jobPost.getTitle())
                .snippet(jobPost.getDescription()));
        assert marker != null;
        marker.setTag(this.jobPost);

        map.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
            @Override
            public void onInfoWindowClick(Marker marker) {
                Intent viewIntent;

                viewIntent = new Intent(EmployeeJobSearchActivity.this, DetailedJobPostActivity.class);
                viewIntent.putExtra("jobPost", (JobPost)marker.getTag());
                startActivity(viewIntent);
            }
        });
    }

    /**
     * method to make a JobPost object to pass to detailed job post
     * @param dataSnapshot DataSnapshot
     * @return JobPost
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public JobPost makeJobObject(DataSnapshot dataSnapshot){
        Double jobLatitude = (Double)dataSnapshot.child("latitude").getValue();
        Double jobLongitude = (Double)dataSnapshot.child("longitude").getValue();
        String jobTitle = (String)dataSnapshot.child("title").getValue();
        String jobDescription = (String)dataSnapshot.child("description").getValue();
        Float jobSalary = Float.valueOf((Long)dataSnapshot.child("salary").getValue());
        int jobDuration = Math.toIntExact((Long) dataSnapshot.child("duration").getValue());
        Date jobStartDate = convertToDate(dataSnapshot.child("startDate").getValue().toString());
        String jobType = (String)dataSnapshot.child("type").getValue();
        String jobEmployerEmail = (String)dataSnapshot.child("employerEmail").getValue();
        Integer jobID = Math.toIntExact((Long)dataSnapshot.child("jobID").getValue());

        this.jobPost = new JobPost(jobTitle, jobSalary, jobDuration, jobDescription, jobStartDate, jobLongitude,
                jobLatitude, jobType, jobEmployerEmail);

        return jobPost;
    }

    /**
     * method to set up default status on map when permissions denied
     */
    public void setDefaultMap() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot: snapshot.getChildren()) {
                    makeJobMarker(dataSnapshot);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error loading job postings",
                        Toast.LENGTH_SHORT).show();
            }
        });

        map.moveCamera(CameraUpdateFactory
                .newLatLngZoom(defaultLocation, DEFAULT_ZOOM));
        map.getUiSettings().setMyLocationButtonEnabled(false);
    }

    /**
     * method to check database for search keyword
     * @param dataSnapshot DataSnapshot
     * @param jobName String
     * @return Boolean
     */
    public Boolean checkForSearchTerm(DataSnapshot dataSnapshot, String jobName) {
        String title = (String)dataSnapshot.child("title").getValue();
        String description = (String)dataSnapshot.child("description").getValue();

        assert title != null;
        if (title.contains(jobName)) return true;
        assert description != null;
        return description.contains(jobName);
    }

    /**
     * method to convert String date in form dd/MM/yyyy to Date format
     * @param startDate String
     * @return Date
     */
    protected Date convertToDate(String startDate){
        Date newDate = new Date();
        java.text.SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try{
            newDate = format.parse(startDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return newDate;
    }
}