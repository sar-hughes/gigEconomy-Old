package ca.dal.csci3130.quickcash.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;


import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.common.Constants;
import ca.dal.csci3130.quickcash.jobPostings.AddJobActivity;
import ca.dal.csci3130.quickcash.jobPostings.EmployerJobSearchActivity;
import ca.dal.csci3130.quickcash.usermanagement.LoginActivity;
import ca.dal.csci3130.quickcash.usermanagement.SessionManager;

 public class EmployerHomeActivity extends AppCompatActivity implements OnMapReadyCallback, View.OnClickListener {

     private GoogleMap map;
     private DatabaseReference databaseReference;
    private SessionManager newSession;

     /**
      * onCreate method for employerHomeActivity
      * @param savedInstanceState
      */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employer_home);
        Context context = getApplicationContext();
        newSession = new SessionManager(context);
        String fName = newSession.getKeyName();
        String lName = newSession.getKeyLastName();

        //welcome message
        TextView tv = (TextView) findViewById(R.id.welcome);
        tv.setText("Welcome Employer " + fName+" "+lName);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        FirebaseDatabase db = FirebaseDatabase.getInstance(Constants.FIREBASE_URL);
        databaseReference = db.getReference(AddJobActivity.class.getSimpleName());

        // logout button function
        Button logoutBtn = (Button) findViewById(R.id.logout);
        logoutBtn.setOnClickListener(this);

        //addJob button function
        Button addJob = (Button) findViewById(R.id.jobPost);
        addJob.setOnClickListener(this);

        //pastPostings search function
        Button pastPostsBtn = (Button) findViewById(R.id.searchPostings);
        pastPostsBtn.setOnClickListener(this);

    }

     /**
      * onclick method for buttons
      * @param view
      */
     @Override
     public void onClick(View view) {
        //for logout
         if(view.getId()== R.id.logout){
             // clear session / shared preferences
             newSession.logoutUser();

             // redirect t login page
             Intent logoutIntent = new Intent(EmployerHomeActivity.this, LoginActivity.class);
             startActivity(logoutIntent);
         }
         //for add job
         else if(view.getId()==R.id.jobPost){
             //Redirect to addJobPosting activity
             Intent viewIntent = new Intent(EmployerHomeActivity.this, AddJobActivity.class);
             startActivity(viewIntent);
         }
         // for search past job postings
         else if(view.getId()== R.id.searchPostings){
             Intent viewIntent = new Intent(EmployerHomeActivity.this, EmployerJobSearchActivity.class);
             startActivity(viewIntent);
         }
     }

    /**
     * Method to disable the back button. Tells User and returns
     */
    @Override
    public void onBackPressed() {
        Toast.makeText(getApplicationContext(), "Cannot go back", Toast.LENGTH_SHORT).show();
    }

     /**
      * google map set up
      * @param googleMap
      */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        // here the map is set at zoom level 10 (City view)
        CameraUpdateFactory.zoomTo(10);
        //here markers can be added

        databaseReference.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot: snapshot .getChildren()) {
                    Double jobLatitude = (Double)dataSnapshot.child("latitude").getValue();
                    Double jobLongitude = (Double)dataSnapshot.child("longitude").getValue();
                    String jobTitle = (String)dataSnapshot.child("title").getValue();
                    String jobDescription = (String)dataSnapshot.child("description").getValue();
                    LatLng latLng = new LatLng(jobLatitude, jobLongitude);

                    Marker job = map.addMarker(
                            new MarkerOptions()
                                    .position(latLng)
                                    .title(jobTitle)
                                    .snippet(jobDescription)
                    );
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Error loading job postings", Toast.LENGTH_SHORT).show();
            }
        });

        //here set the default view (no location access) to be someplace in Canada
        LatLng canada = new LatLng(60, -100);
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(canada, 3));

    }

}