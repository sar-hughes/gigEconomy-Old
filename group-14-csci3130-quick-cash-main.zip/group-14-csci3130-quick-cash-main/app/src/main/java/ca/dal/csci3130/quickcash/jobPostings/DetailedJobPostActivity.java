package ca.dal.csci3130.quickcash.jobPostings;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.maps.android.data.geojson.GeoJsonLayer;

import org.junit.validator.TestClassValidator;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.Nullable;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.usermanagement.SessionManager;

public class DetailedJobPostActivity extends EmployeeJobSearchActivity implements Serializable, OnMapReadyCallback {

    private JobPost jobPost;
    private MapView mMapView;
    private GoogleMap map;
    private static final int DEFAULT_ZOOM = 15;

    /**
     * onCreate method for DetailedJobPost activity
     * @param savedInstanceState Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_job_post);
        Context context = getApplicationContext();
        SessionManager newSession = new SessionManager(context);
        this.jobPost = (JobPost) getIntent().getSerializableExtra("jobPost");
        String employerFName = newSession.getKeyName();
        String employerLName = newSession.getKeyLastName();
        setText(employerFName, employerLName);

        this.jobPost = (JobPost) getIntent().getSerializableExtra("jobPost");

        MapView mMapView = (MapView) findViewById(R.id.job_location);

        if (mMapView != null) {
            mMapView.onCreate(savedInstanceState);
            mMapView.getMapAsync(this);
        }


    }

    /**
     * map set up
     * @param googleMap GoogleMap
     */
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        MapsInitializer.initialize(getApplicationContext());
        double jobLatitude = jobPost.getLatitude();
        double jobLongitude = jobPost.getLongitude();
        LatLng location = new LatLng(jobLatitude, jobLongitude);
        map = googleMap;
        map.addMarker(new MarkerOptions().position(location).title("Marker position"));
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, DEFAULT_ZOOM));
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }

    /**
     * method to set the correct text on screen according to which job post was selected
     * @param firstName String
     * @param lastName String
     */
    protected void setText(String firstName, String lastName){

        String jobTitle = (String) jobPost.getTitle();
        Float jobSalary = (Float) jobPost.getSalary();
        Integer jobDuration = (Integer) jobPost.getDuration();
        String jobDescription = (String) jobPost.getDescription();
        String employerEmail = (String) jobPost.getEmployerEmail();
        Date Start = (Date) jobPost.getStartDate();

        TextView jobTitleTextView = (TextView) findViewById(R.id.JobTitle);
        jobTitleTextView.setText(jobTitle);

        TextView jobDescriptionTextView = (TextView) findViewById(R.id.job_desc);
        jobDescriptionTextView.setText(jobDescription);

        TextView jobSalaryTextView = (TextView) findViewById(R.id.Salary);
        jobSalaryTextView.setText(Float.toString(jobSalary));

        TextView jobDurationTextView = (TextView) findViewById(R.id.job_duration);
        jobDurationTextView.setText(Integer.toString(jobDuration));

        TextView employerEmailTextView = (TextView) findViewById(R.id.employer_email);
        employerEmailTextView.setText(employerEmail);

        TextView employerFirstName = (TextView) findViewById(R.id.employer_name);
        employerFirstName.setText(firstName + " " + lastName);

        TextView jobStartDate = (TextView) findViewById(R.id.start_date);
        jobStartDate.setText(Start.toString());
    }
}
