package ca.dal.csci3130.quickcash.common;

public class Utils {
    //ET5: Encrypting the password
    public static String EncryptingPassword(String password) {

        char[] array = password.toCharArray();
        for (int i = 0; i < array.length; i++) {
            array[i] = (char) (array[i] ^ 9);
        }
        return new String(array);
    }
}
