package ca.dal.csci3130.quickcash.usermanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.Objects;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

public class ViewPreferencesActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener, Serializable, View.OnClickListener {

    String email;

    static final String[] jobType = {"Dog grooming", "Driver", "Cook", "Developer", "No preference"};

    static final String[] salaryRange = {"12.95/hr-13.95/hr", "13.95/hr-15.95/hr", "15.95/hr-19.95/hr", "20/hr+", "No preference"};

    static final String[] duration = {"1hr-2hr", "2hr-3hr", "3hr-4hr", "4hr-5hr", "6hr+", "No preference"};

    transient Spinner spin1;
    transient Spinner spin2;
    transient Spinner spin3;

    static String jobTypePref = "No preference";
    static String salaryPref = "No preference";
    static String durationPref = "No preference";

    int jobTypePrefPosition = 0;
    int salaryPrefPosition = 0;
    int durationPrefPosition = 0;

    transient UserDAO userDAO;
    transient DatabaseReference userstable;

    /**
     * onCreate method for ViewPreferencesActivity
     * @param savedInstanceState Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_preferences);

        // set up database reference
        userDAO = new UserDAO();
        userstable = userDAO.getDatabaseReference();

        // get extra value
        email = (String)getIntent().getSerializableExtra("email");

        // set up spinners
        setupSpinners();

        // button function for done
        Button doneBtn = (Button) findViewById(R.id.done);
        doneBtn.setOnClickListener(this);

    }

    /**
     * method to set and get the position in array of the job type preference
     * @return int
     */
    public static int getJobPos() {
        for(int i=0; i<5; i++){
            if(jobTypePref.equals(jobType[i])){
                return i;
            }
        }
        return 0;
    }

    /**
     * method to set and get the position in the array of the salary preference
     * @return int
     */
    public static int getSalPos(){
        for(int i=0;i<5;i++){
            if(salaryPref.equals(salaryRange[i])){
                return i;
            }
        }
        return 0;
    }

    /**
     * method to set and get the position in the array of the duration preference
     * @return int
     */
    public static int getDurPos(){
        for(int i=0;i<6;i++){
            if(durationPref.equals(duration[i])){
                return i;
            }
        }
        return 0;
    }

    /**
     * method for setting up the preference selector spinners
     */
    public void setupSpinners(){
        //Getting the instance of Spinner and applying OnItemSelectedListener on it

        spin1 = (Spinner) findViewById(R.id.jobTypeSpinner);
        spin2 = (Spinner) findViewById(R.id.salarySpinner);
        spin3 = (Spinner) findViewById(R.id.durationSpinner);


        //Creating the ArrayAdapter instance having the lists
        ArrayAdapter jobT = new ArrayAdapter(this, android.R.layout.simple_spinner_item, jobType);
        ArrayAdapter salaryR = new ArrayAdapter(this, android.R.layout.simple_spinner_item, salaryRange);
        ArrayAdapter durationS = new ArrayAdapter(this, android.R.layout.simple_spinner_item, duration);
        jobT.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        salaryR.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        durationS.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin1.setAdapter(jobT);
        spin2.setAdapter(salaryR);
        spin3.setAdapter(durationS);


        // Setting default value shown on spinners to be the set preferences in database

        userstable.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean errorFlag = false;
                for (DataSnapshot dataSnapshot: snapshot .getChildren()){
                    if (Objects.requireNonNull(dataSnapshot.child("email").getValue()).equals(email) && Objects.requireNonNull(dataSnapshot.child("isEmployee").getValue()).equals("employee")){

                        errorFlag = true;

                        jobTypePref = (String)dataSnapshot.child("jobTypePref").getValue();
                        salaryPref = (String)dataSnapshot.child("salaryPref").getValue();
                        durationPref = (String)dataSnapshot.child("durationPref").getValue();

                        break;
                    }
                }
                if (!errorFlag) {
                    Toast.makeText(getApplicationContext(), "user does not exist, or is not an employee", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // on cancelled do nothing
            }
        });

        // get position to set the spinner selection on to start
        jobTypePrefPosition = getJobPos();
        salaryPrefPosition = getSalPos();
        durationPrefPosition = getDurPos();

        spin1.setSelection(jobTypePrefPosition);
        spin2.setSelection(salaryPrefPosition);
        spin3.setSelection(durationPrefPosition);

        // set item selected listeners for each spinner
        spin1.setOnItemSelectedListener(this);
        spin2.setOnItemSelectedListener(this);
        spin3.setOnItemSelectedListener(this);
    }



    /**
     * method for when a new spinner item is selected (new preference made)
     * @param arg0 AdapterView<?>
     * @param arg1 View
     * @param position int
     * @param id long
     */
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {

        // set shown item on spinners to be selected and set preference
        // for new job type preference
        if(arg0.getId() == R.id.jobTypeSpinner) {
            spin1.setSelection(position);
            jobTypePref = jobType[position];
        }
        // for new salary preference
        else if(arg0.getId() == R.id.salarySpinner) {
            spin2.setSelection(position);
            salaryPref = salaryRange[position];
        }
        // for new duration preference
        else if(arg0.getId() == R.id.durationSpinner) {
            spin3.setSelection(position);
            durationPref = duration[position];
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // do nothing
    }

    /**
     * onClick method for buttons
     * @param view View
     */
    @Override
    public void onClick(View view) {

        // when done is clicked change the preferences in the database for the current user to be the newly selected items
        userstable.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean errorFlag = false;
                for (DataSnapshot dataSnapshot: snapshot .getChildren()){
                    if (Objects.requireNonNull(dataSnapshot.child("email").getValue()).equals(email) && Objects.requireNonNull(dataSnapshot.child("isEmployee").getValue()).equals("employee")){

                        errorFlag = true;

                        dataSnapshot.child("jobTypePref").getRef().setValue(jobTypePref);
                        dataSnapshot.child("salaryPref").getRef().setValue(salaryPref);
                        dataSnapshot.child("durationPref").getRef().setValue(durationPref);

                        break;
                    }
                }
                if (!errorFlag) {
                    Toast.makeText(getApplicationContext(), "user does not exist, or is not an employee", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // do nothing
            }
        });

        // go back to the employee home page
        Intent viewIntent = new Intent(ViewPreferencesActivity.this, EmployeeHomeActivity.class);
        startActivity(viewIntent);
    }
}