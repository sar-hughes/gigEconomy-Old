package ca.dal.csci3130.quickcash.jobPostings;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import ca.dal.csci3130.quickcash.common.AbstractDAO;
import ca.dal.csci3130.quickcash.common.Constants;
import ca.dal.csci3130.quickcash.usermanagement.UserInterface;

public class AddJobDAO extends AbstractDAO {
    private final DatabaseReference databaseReference;

    /**
     * User database object constructor
     */
    public AddJobDAO() {
        // FIREBASE_URL needs to be updated
        FirebaseDatabase db = FirebaseDatabase.getInstance(Constants.FIREBASE_URL);
        databaseReference = db.getReference(AddJobActivity.class.getSimpleName());
    }

    /**
     *
     * @return reference to the database
     */
    @Override
    public DatabaseReference getDatabaseReference() {
        return databaseReference;
    }

    /**
     * Takes a user object and pushes it to the database
     * @param post
     * @return
     */
    @Override
    public Task<Void> add(JobPostInterface post) {
        return databaseReference.push().setValue(post);
    }

}

