package ca.dal.csci3130.quickcash.jobPostings;

import android.content.Intent;

import java.io.Serializable;
import java.util.*;

public class JobPost implements JobPostInterface, Serializable {

    private String title;
    private float salary;
    private int duration;
    private String description;
    private Date startDate;
    private double longitude;
    private double latitude;
    private String type;
    private static int numJobs;
    private final int jobID;
    private String employerEmail;
    private ArrayList<String> applicants;
    private String accepted;

    /**
     * Job post constructor
     * @param title
     * @param salary
     * @param duration
     * @param description
     * @param startDate
     * @param longitude
     * @param latitude
     * @param type
     * @param employerEmail
     */
    public JobPost(String title, float salary, int duration, String description, Date startDate, double longitude, double latitude, String type, String employerEmail){
        this.title = title;
        this.salary = salary;
        this.duration = duration;
        this.description = description;
        this.startDate = startDate;
        this.longitude = longitude;
        this.latitude = latitude;
        this.type = type;
        numJobs++;
        jobID = numJobs;
        this.employerEmail = employerEmail;
        applicants = new ArrayList<>();
        accepted = null;
    }


    /**
     * get method for job title
     * @return String
     */
    @Override
    public String getTitle() {
        return this.title;
    }

    /**
     * set method for job title
     * @param title
     */
    @Override
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * get method for salary
     * @return float
     */
    @Override
    public float getSalary() {
        return this.salary;
    }

    /**
     * set method for salary
     * @param salary
     */
    @Override
    public void setSalary(float salary) {
        this.salary = salary;
    }

    /**
     * get method for duration
     * @return int
     */
    @Override
    public int getDuration() {
        return this.duration;
    }

    /**
     * set method for duration
     * @param duration
     */
    @Override
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * get method for description
     * @return String
     */
    @Override
    public String getDescription() {
        return this.description;
    }

    /**
     * set method for description
     * @param description
     */
    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * get method for start date
     * @return Date
     */
    @Override
    public Date getStartDate() {
        return this.startDate;
    }

    /**
     * set method for start date
     * @param startDate
     */
    @Override
    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    /**
     * get method for longitude
     * @return double
     */
    @Override
    public double getLongitude() {
        return this.longitude;
    }

    /**
     * set method for longitude
     * @param longitude
     */
    @Override
    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    /**
     * get method for latitude
     * @return double
     */
    @Override
    public double getLatitude() {
        return this.latitude;
    }

    /**
     * set method for latitude
     * @param latitude
     */
    @Override
    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    /**
     * get method for type
     * @return String
     */
    @Override
    public String getType() {
        return this.type;
    }

    /**
     * set method for type
     * @param type
     */
    @Override
    public void setType(String type) {
        this.type = type;
    }

    /**
     * get method for number of jobs
     * @return int
     */
    @Override
    public int getNumJobs(){
        return numJobs;
    }

    /**
     * get method for job ID
     * @return int
     */
    @Override
    public int getJobID() {
        return jobID;
    }

    /**
     * get method for employer email
     * @return String
     */
    @Override
    public String getEmployerEmail() {
        return this.employerEmail;
    }

    /**
     * @param email
     */
    @Override
    public void setEmployerEmail(String email) {
        this.employerEmail = email;
    }

    /**
     * @return ArrayList<String>
     */
    @Override
    public ArrayList<String> getApplicants() {
        return this.applicants;
    }

    /**
     *
     * @param applicants
     */
    @Override
    public void setApplicants(ArrayList<String> applicants) {
        this.applicants = applicants;
    }

    /**
     *
     * @return String
     */
    @Override
    public String getAccepted() {
        return this.accepted;
    }

    /**
     *
     * @param accepted
     */
    @Override
    public void setAccepted(String accepted) {
        this.accepted = accepted;
    }

    /**
     *
     * @param email
     */
    public void addApplicant(String email){
        this.applicants.add(email);
    }

    /**
     *
     * @param email
     */
    public void removeApplicant(String email){
        this.applicants.remove(email);
    }
}
