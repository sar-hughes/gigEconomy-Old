package ca.dal.csci3130.quickcash.usermanagement;

public class User implements UserInterface {

    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String password;
    private String confirmPassword;
    private String isEmployee; // Values y = yes, n= no.
    private String jobTypePref;
    private String salaryPref;
    private String durationPref;


    /**
     * User constructor
     * @param firstName of user
     * @param lastName of user
     * @param email of user
     * @param phone of user
     * @param password of user
     * @param confirmPassword of user
     * @param isEmployee of user
     */
    public User(String firstName, String lastName, String email, String phone, String password,
                String confirmPassword, String isEmployee) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.isEmployee = isEmployee;

        if(isEmployee.equals("employee")) {
            String noPref = "No preference";
            this.jobTypePref = noPref;
            this.salaryPref = noPref;
            this.durationPref = noPref;
        }
        else{
            this.jobTypePref = null;
            this.salaryPref = null;
            this.durationPref = null;
        }
    }

    public User() {
    }

    /**
     * getter for User FirstName
     * @return firstName
     */
    @Override
    public String getFirstName() {
        return firstName;
    }

    /**
     * Setter method for the Users first Name
     * @param firstName
     */
    @Override
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /**
     * getter for User LastName
     * @return LastName
     */
    @Override
    public String getLastName() {
        return lastName;
    }

    /**
     * Setter method for the Users Last Name
     * @param lastName
     */
    @Override
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * getter for User Email
     * @return email
     */
    @Override
    public String getEmail() {
        return email;
    }

    /**
     * Setter method for the Users Email
     * @param email
     */
    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * getter for User Phone Number
     * @return phone
     */
    @Override
    public String getPhone() {
        return phone;
    }

    /**
     * Setter method for the Users Phone Number
     * @param phone
     */
    @Override
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * getter for User Password
     * @return Password
     */
    @Override
    public String getPassword() {
        return password;
    }

    /**
     * Setter method for the Users Password
     * @param password
     */
    @Override
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * getter for User Confirm Password
     * @return confirmPassword
     */
    @Override
    public String getConfirmPassword() {
        return confirmPassword;
    }

    /**
     * Setter method for the Users Confirm Password
     * @param confirmPassword
     */
    @Override
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    /**
     * getter for User Employment Status
     * @return isEmployee
     */
    @Override
    public String getIsEmployee() {
        return isEmployee;
    }

    /**
     * Setter method for the Users Employment Type
     * @param isEmployee
     */
    @Override
    public void setIsEmployee(String isEmployee) {
        this.isEmployee = isEmployee;
    }

    public void setJobTypePref(String typePref){
        this.jobTypePref = typePref;
    }

    public String getJobTypePref(){
        return this.jobTypePref;
    }

    public void setSalaryPref(String salPref){
        this.salaryPref = salPref;
    }

    public String getSalaryPref(){
        return this.salaryPref;
    }

    public void setDurationPref(String durPref){
        this.durationPref = durPref;
    }

    public String getDurationPref(){
        return this.durationPref;
    }

}
