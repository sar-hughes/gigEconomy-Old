package ca.dal.csci3130.quickcash.usermanagement;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.Serializable;

public class SessionManager implements SessionManagerInterface, Serializable {
    //ET5: If details match, create a session using shared preferences object. Add the user as a value to the shared pref key.
    private SharedPreferences sharedPreferences;
    private static String spEmail = "email";
    private String spPassword = "password";
    private String spfirstName = "firstName";
    private String splastName = "lastName";

    /**
     * Session Manager constructor
     * @param context
     */
    public SessionManager(Context context){
        String spKey = "userSession";
        sharedPreferences = context.getSharedPreferences(spKey, Context.MODE_PRIVATE);
    }

    /**
     * Login Session constructor- sets data for the user when logged in
     * @param email
     * @param password
     * @param firstName
     * @param lastName
     */
    @Override
    public void createLoginSession(String email, String password, String firstName, String lastName, String userType) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(spEmail, email);
        editor.putString(spPassword, password);
        editor.putString(spfirstName, firstName);
        editor.putString(splastName, lastName);
        String spUserType = "userType";
        editor.putString(spUserType, userType);
        editor.apply();
    }

    /**
     * Check log in method
     *Checks to see if A user is logged in
     */
    @Override
    public void checkLogin() {
        //never needed
    }

    /**
     *clears the sharedPreferences object and logs user out
     */
    @Override
    public void logoutUser() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

    /**
     * @return if user is logged in
     */
    @Override
    public boolean isLoggedIn() {
        return false;
    }

    /**
     * getKeyName() method
     * @return String value of the Users First Name
     */
    @Override
    public String getKeyName() {

        return (sharedPreferences.getString(spfirstName, ""));
    }
    /**
     * getKeyLastName() method
     * @return String value of the Users Last Name
     */
    @Override
    public String getKeyLastName(){
        return (sharedPreferences.getString(splastName,""));
    }
    /**
     * getKeyEmail() method
     * @return String value of the Users Email
     */
    @Override
    public String getKeyEmail() {
        return (sharedPreferences.getString(spEmail,""));
    }
}
