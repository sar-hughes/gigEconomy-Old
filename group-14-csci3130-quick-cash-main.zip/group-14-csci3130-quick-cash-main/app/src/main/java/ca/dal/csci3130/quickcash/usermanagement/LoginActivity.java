package ca.dal.csci3130.quickcash.usermanagement;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import ca.dal.csci3130.quickcash.R;
import ca.dal.csci3130.quickcash.common.Utils;
import ca.dal.csci3130.quickcash.home.EmployeeHomeActivity;
import ca.dal.csci3130.quickcash.home.EmployerHomeActivity;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
   private DatabaseReference userstable = null;
    private SessionManager sessionManager;


    /**
     * get method for users email
     * @return String
     */
    protected String getEmail() {
        EditText email = findViewById(R.id.email);
        return email.getText().toString().trim();
    }

    /**
     * get method for users password
     * @return String
     */
    protected String getPassword() {
        EditText password = findViewById(R.id.password);
        return password.getText().toString().trim();
    }

    /**
     * onCreate method for Login activity
     * @param savedInstanceState Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        UserDAO userDAO = new UserDAO();
        userstable = userDAO.getDatabaseReference();
        sessionManager = new SessionManager(this);

        //hyperlink function
        TextView hyperlink = (TextView) findViewById(R.id.activity_main_link);
        hyperlink.setOnClickListener(this);

        //login button function
        Button loginBtn = (Button) findViewById(R.id.Btn_Login);
        loginBtn.setOnClickListener(this);
    }

    /**
     * onClick method for buttons
     * @param view
     */
    @Override
    public void onClick(View view) {
        //for hyperlink
        if(view.getId()== R.id.activity_main_link){
            Intent viewIntent = new Intent(LoginActivity.this, SignupActivity.class);
            startActivity(viewIntent);

        }
        //for login
        else if(view.getId()== R.id.Btn_Login){
            String email = getEmail();
            String password =getPassword();
            tryLogin(email, password);
        }
    }

    //ET2: Create a backend logic for capturing the details for US3 and US4

    /**
     *TryLogin()
     * takes an email and password, checks to see if they match a user on Firebase database,
     * redirects to employment status page on login.
     * @param email String
     * @param password String
     */
    public void tryLogin(String email, String password) {
        if(isEmailEmpty(email) || isPassEmpty(password)) {
            Toast.makeText(getApplicationContext(), "please input the email and password", Toast.LENGTH_SHORT).show();
            return;
        }
        String finalPassword = Utils.EncryptingPassword(password);
        userstable.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean errorFlag = false;
                for (DataSnapshot dataSnapshot: snapshot .getChildren()){
                    if (Objects.requireNonNull(dataSnapshot.child("email").getValue()).equals(email) && Objects.requireNonNull(dataSnapshot.child("password").getValue()).equals(finalPassword)){

                        errorFlag = true;

                        String firstName = (String)dataSnapshot.child("firstName").getValue();
                        String lastName = (String)dataSnapshot.child("lastName").getValue();
                        String userType = (String)dataSnapshot.child("isEmployee").getValue();
                        sessionManager.createLoginSession(email, finalPassword, firstName, lastName, userType);
                        boolean isEmployer = dataSnapshot.child("isEmployee").getValue().equals("employer");

                        Intent viewIntent;
                        //ET6: Redirect to home page based on the user type.
                        if(isEmployer){

                            viewIntent = new Intent(LoginActivity.this, EmployerHomeActivity.class);
                        }else{
                            viewIntent = new Intent(LoginActivity.this, EmployeeHomeActivity.class);
                        }

                        startActivity(viewIntent);
                        break;
                    }
                }
                if (!errorFlag) {
                    Toast.makeText(getApplicationContext(), "email or password was incorrect.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // do nothing if cancelled
            }
        });
    }

    /**
     * Method to disable the back button. Tells User and returns
     */
    @Override
    public void onBackPressed(){
        Toast.makeText(getApplicationContext(), "Can not go back", Toast.LENGTH_SHORT).show();
    }

    // methods to check if credentials are empty or not
    public boolean isEmailEmpty(String email){
        return email.isEmpty();
    }

    public boolean isPassEmpty(String password){
        return password.isEmpty();
    }

}
