package ca.dal.csci3130.quickcash.common;

/**
 * Constants for project
 */
public class Constants {
    public static final String FIREBASE_URL = "https://quickcash-8960c-default-rtdb.firebaseio.com/";
    // Add all your constants here
    public final String sample = "Sample";
}
